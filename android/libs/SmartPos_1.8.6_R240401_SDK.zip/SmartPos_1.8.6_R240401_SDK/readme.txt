Please read zcs_pos_guide_EN.pdf in 'doc' directory at first.

contents of all directory:
--doc         --  Documentation of api and guide.
--emv_data    --  Emv aid and capk files
--libs        --  .so and .jar files
--demo        --  A demo for the sdk which contains almost all the usage of the sdk